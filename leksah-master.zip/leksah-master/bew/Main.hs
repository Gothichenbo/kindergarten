module Main (
    main
) where

import GHCJS.DOM (run)

main = do
--  runWebGUI $ \ webView -> do
    putStrLn "Bewleksah is a version of Leksah that can run in a web browser."
    putStrLn "Nothing working yet."


